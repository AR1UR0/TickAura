La página web se abre desde ./Web/index.html

Hemos puesto esto así porque la carpeta imagenes está usada por varias cosas en nuestro proyecto y la ruta que tiene desde los archivos html es ../Imagenes